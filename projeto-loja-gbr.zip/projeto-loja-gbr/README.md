# PROJETO LOJA GBR 

A Pen created on CodePen.io. Original URL: [https://codepen.io/senhorvaldemar/pen/MWQqBXZ](https://codepen.io/senhorvaldemar/pen/MWQqBXZ).

